# -*- coding: utf8 -*-
WTF_CSRF_ENABLED= True
SECRET_KEY= 'oops_so_tough!'


# DATABASE CONFIGURATION
import os
basedir= os.path.abspath(os.path.dirname(__file__))
if os.environ.get('DATABASE_URL') not in os.environ:
    SQLALCHEMY_DATABASE_URI = ('sqlite:///' + os.path.join(basedir, 'app.db') + '?check_same_thread=False')
else:
    SQLALCHEMY_DATABASE_URI = os.environ['DATABASE_URL']
SQLALCHEMY_MIGRATE_REPO = os.path.join(basedir, 'db_repository')
SQLALCHEMY_RECORD_QUERIES = True


ALTMETRIC_KEY= '2755b2a647e8ed7d6f4eb5c908ea8a5f'

import os
import psycopg2
import urlparse

#urlparse.uses_netloc.append("postgres")
#url = urlparse.urlparse(os.environ["DATABASE_URL"])
"""
conn = psycopg2.connect(
            database=url.path[1:],
            user=url.username,
            password=url.password,
            host=url.hostname,
            port=url.port
                            )"""
